package example;

			import com.oracle.bmc.hdfs.BmcFilesystem;
			import com.oracle.bmc.http.ClientConfigurator;

			import org.apache.spark.SparkConf;
			import org.apache.spark.api.java.JavaSparkContext;
			import org.apache.spark.api.java.function.ForeachFunction;
			import org.apache.spark.sql.RowFactory;
			import org.apache.spark.sql.SparkSession;

			import java.net.URI;
			import java.nio.charset.StandardCharsets;
			import java.text.MessageFormat;
			import java.util.List;

			import com.oracle.bmc.secrets.SecretsClient;
			import com.oracle.bmc.secrets.requests.GetSecretBundleRequest;
			import com.oracle.bmc.secrets.responses.GetSecretBundleResponse;
			import com.oracle.bmc.secrets.model.Base64SecretBundleContentDetails;
			import org.apache.commons.codec.binary.Base64;
			import com.oracle.bmc.auth.BasicAuthenticationDetailsProvider;

			import java.util.ArrayList;
			import org.apache.spark.sql.Row;
			import org.apache.spark.sql.streaming.DataStreamWriter;
			import org.apache.spark.sql.streaming.OutputMode;
			import org.apache.spark.sql.streaming.StreamingQuery;
			import org.apache.spark.sql.streaming.StreamingQueryException;
			import org.apache.spark.sql.types.DataTypes;
			import org.apache.spark.sql.types.StructType;
			import org.apache.spark.sql.Dataset;
			import java.util.Map;
			import java.util.HashMap;
			import oracle.jdbc.driver.OracleConnection;

	// This demo illustrates:
// 1. The delegation token path must be looked up in the Driver and passed to the Executor.
// 2. If the token path is null, assume you are running locally and load an API key.
// 3. Using the HDFS-Connector to create an HDFS FileSystem to connect to Object Storage.
	public class Example {

		// TODO: Set these values for your sepcific OCI environment
		private static final String NAMESPACE = "";
		private static final String BUCKET_NAME = "data"; // ensure that you create this bucket

		private static final String OCI_URI = "oci://" + BUCKET_NAME + "@" + NAMESPACE;
		private static final String OCI_URI_WALLET = "oci://Wallet@" + NAMESPACE;
		private static final String SAMPLE_JOB_PATH = "/Example";
		private static final String INPUT_FILE = SAMPLE_JOB_PATH + "/input.dat";

		// Customize these before you start.
		private static String OBJECT_STORAGE_NAMESPACE = "";
		private static String INPUT_PATH = "oci://data@" + OBJECT_STORAGE_NAMESPACE + "/organizations.csv";
		private static String DATABASE_NAME = "logs";
		private static String PASSWORD_SECRET_OCID = "";
		private static String WALLET_PATH = "oci://Wallet@" + OBJECT_STORAGE_NAMESPACE + "/Wallet_" + DATABASE_NAME + ".zip";
		private static String TNS_NAME = DATABASE_NAME + "_high";
		private static String USER="ADMIN";
		private static String TARGET_DATABASE_TABLE="processed_logs";

		private static String bootstrapServers = "cell-1.streaming.us-ashburn-1.oci.oraclecloud.com:9092";
		private static String topics = "kafka_like";
		private static String streamPoolId = "";
		private static String kafkaUsername = "hoshikawaoraclecloud/oracleidentitycloudservice/hoshikawa2@hotmail.com/" + streamPoolId;
		private static String kafkaPassword = "";

		public static void main(String[] args) throws Exception {

			// ---------------------------------------------------------------------
			// 0 - Get our Spark session.
			System.out.println("---------------------------------------------------------------------------------");
			System.out.println("0 - Get our Spark session.");
			SparkConf conf = new SparkConf();
			String master = conf.get("spark.master", "local[*]");
			SparkSession spark = SparkSession.builder().appName("Example").master(master).getOrCreate();
			JavaSparkContext jsc = JavaSparkContext.fromSparkContext(spark.sparkContext());

			String delegationTokenPath = OboTokenClientConfigurator.getDelegationTokenPath();

			try (final BmcFilesystem fs = new BmcFilesystem())
			{
				fs.initialize(new URI(OCI_URI), OboTokenClientConfigurator.getConfiguration(
						jsc.hadoopConfiguration(), delegationTokenPath));
			}
			// ---------------------------------------------------------------------

			// ---------------------------------------------------------------------
			// 1 - Read File from Object Storage
			System.out.println("---------------------------------------------------------------------------------");
			System.out.println("1 - Read File from Object Storage");
			Dataset<Row> dataset = spark.sqlContext().read()
					.option("header", "true")
					.option("inferSchema", "true")
					.csv(INPUT_PATH);
			dataset.show();
			// ---------------------------------------------------------------------

			// ---------------------------------------------------------------------
			// 2 - Autonomous Database Wallet
			System.out.println("---------------------------------------------------------------------------------");
			System.out.println("2 - Autonomous Database Wallet");
			String passwordOcid = PASSWORD_SECRET_OCID; // TODO <the vault secret OCID>

			BasicAuthenticationDetailsProvider provider =
					OboTokenClientConfigurator.getAuthProvider(delegationTokenPath);
			ClientConfigurator configurator = OboTokenClientConfigurator.getConfigurator(delegationTokenPath);
			SecretsClient secretsClient = SecretsClient.builder().clientConfigurator(configurator).build(provider);

			// create get secret bundle request
			GetSecretBundleRequest getSecretBundleRequest = GetSecretBundleRequest
					.builder()
					.secretId(passwordOcid)
					.stage(GetSecretBundleRequest.Stage.Current)
					.build();

			// get the secret
			GetSecretBundleResponse getSecretBundleResponse = secretsClient.
					getSecretBundle(getSecretBundleRequest);

			// get the bundle content details
			Base64SecretBundleContentDetails base64SecretBundleContentDetails =
					(Base64SecretBundleContentDetails) getSecretBundleResponse.
							getSecretBundle().getSecretBundleContent();

			// decode the encoded secret
			byte[] secretValueDecoded = Base64.decodeBase64(base64SecretBundleContentDetails.getContent());
			System.out.println("Secret: " + new String(secretValueDecoded, StandardCharsets.UTF_8));
			// ---------------------------------------------------------------------

			// ---------------------------------------------------------------------
			// 3 - Wallet and Secret
			System.out.println("---------------------------------------------------------------------------------");
			System.out.println("3 - Wallet and Secret");
			// TODO <set these values as appropriate to access your ADW using your ADW wallet
			String walletPath = WALLET_PATH; //OCI_URI- URI of bucket where you have uploaded wallet
			String user = "ADMIN"; //DB user name
			String tnsName = TNS_NAME; // this can be found inside of the wallet.zip (unpack it), then open tnsnames.ora

			// Download the wallet from object storage and distribute it.
			String tmpPath = DataFlowDeployWallet.deployWallet(new URI(OCI_URI_WALLET), spark.sparkContext(),
					OboTokenClientConfigurator.getConfiguration(jsc.hadoopConfiguration(), delegationTokenPath), walletPath);
			// ---------------------------------------------------------------------

			// ---------------------------------------------------------------------
			// 4 - Write to the Autonomous Database
			System.out.println("---------------------------------------------------------------------------------");
			System.out.println("4 - Write to the Autonomous Database");
			String jdbcUrl = MessageFormat.format("jdbc:oracle:thin:@{0}?TNS_ADMIN={1}", tnsName, tmpPath);
			System.out.println("JDBC URL " + jdbcUrl);

			String password = new String(secretValueDecoded);
			// ---------------------------------------------------------------------

			// ---------------------------------------------------------------------
			// 5 - Save data to ADW.
			System.out.println("---------------------------------------------------------------------------------");
			System.out.println("5 - Save data to ADW.");
			System.out.println("Saving to ADW");
			Map<String, String> options = new HashMap<String, String>();
			options.put("driver", "oracle.jdbc.driver.OracleDriver");
			options.put("url", jdbcUrl);
			options.put(OracleConnection.CONNECTION_PROPERTY_USER_NAME, user);
			options.put(OracleConnection.CONNECTION_PROPERTY_PASSWORD, password);
			options.put(OracleConnection.CONNECTION_PROPERTY_TNS_ADMIN, tmpPath);
			options.put("dbtable", "organizations");
			dataset.write().format("jdbc").options(options).mode("Overwrite").save();
			System.out.println("Done writing to ADW");
			// ---------------------------------------------------------------------

			// ---------------------------------------------------------------------
			// 6 - Query a table from ADW: SELECT
			System.out.println("---------------------------------------------------------------------------------");
			System.out.println("6 - Query a table from ADW: SELECT");
			Map<String, String> options2 = new HashMap<String, String>();
			options2.put("driver", "oracle.jdbc.driver.OracleDriver");
			options2.put("url", jdbcUrl);
			options2.put(OracleConnection.CONNECTION_PROPERTY_USER_NAME, user);
			options2.put(OracleConnection.CONNECTION_PROPERTY_PASSWORD, password);
			options2.put(OracleConnection.CONNECTION_PROPERTY_TNS_ADMIN, tmpPath);
			options2.put("query", "select * from gdppercapta");
			Dataset<Row> oracleDF2 = spark.read().format("jdbc").options(options2).load();
			oracleDF2.show();
			// ---------------------------------------------------------------------

			// ---------------------------------------------------------------------
			// 7 - Merge data
			System.out.println("---------------------------------------------------------------------------------");
			System.out.println("7 - Merge data");
			dataset.createOrReplaceTempView("organizations");
			oracleDF2.createOrReplaceTempView("gdppercapta");

			spark.sql("SELECT a.`organization id` as organization, a.name, a.country, b.area FROM organizations a, gdppercapta b where a.country = b.country").show();
			// ---------------------------------------------------------------------

			// ---------------------------------------------------------------------
			// 8 - Iteration data
			// Extreme situation if need some iteration
			System.out.println("---------------------------------------------------------------------------------");
			System.out.println("8 - Iteration data");
			Map<String, String> options3 = new HashMap<String, String>();
			options3.put("driver", "oracle.jdbc.driver.OracleDriver");
			options3.put("url", jdbcUrl);
			options3.put(OracleConnection.CONNECTION_PROPERTY_USER_NAME, user);
			options3.put(OracleConnection.CONNECTION_PROPERTY_PASSWORD, password);
			options3.put(OracleConnection.CONNECTION_PROPERTY_TNS_ADMIN, tmpPath);
			options3.put("dbtable", "resultados");
			StructType structure = dataset.schema();
			List<Row> rows = new ArrayList<Row>();
			Dataset<Row> transformedDF = spark.createDataFrame(rows, structure);

			dataset.foreach((ForeachFunction<Row>) row ->
					{
						// Some kind of iteration, like call an API or put on Kafka to produce
						System.out.println(row);
					}
			);
			// ---------------------------------------------------------------------

			// ---------------------------------------------------------------------
			// 9 - Kafka
			/*
			.option("kafka.sasl.mechanism", "OCI-RSA-SHA256")
			.option("kafka.sasl.jaas.config",
				"com.oracle.bmc.auth.sasl.ResourcePrincipalsLoginModule required intent=\"streamPoolId:" + streamPoolId + "\";")

			String jaasTemplate = "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"%s\" password=\"%s\";";
			String jaasCfg = String.format(jaasTemplate, kafkaUsername, kafkaPassword);
			.option("kafka.sasl.mechanism", "PLAIN")
			.option("kafka.sasl.jaas.config",
					jaasCfg)

			 */
			System.out.println("---------------------------------------------------------------------------------");
			System.out.println("9 - Kafka");

			String jaasTemplate = "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"%s\" password=\"%s\";";
			String jaasCfg = String.format(jaasTemplate, kafkaUsername, kafkaPassword);

			/*
			StructType structType = new StructType();
			structType = structType.add("key", DataTypes.StringType, false);
			structType = structType.add("value", DataTypes.StringType, false);

			List<Row> rows = new ArrayList<Row>();
			rows.add(RowFactory.create("test key", "This is an example sentence"));

			Dataset<Row> sentenceDF = spark.sqlContext().createDataFrame(rows, structType);

			sentenceDF.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")
					.write()
					.format("kafka")
					.option("kafka.bootstrap.servers", bootstrapServers)
					.option("topic", topics)
					.option("kafka.security.protocol", "SASL_SSL")
					.option("kafka.sasl.mechanism", "OCI-RSA-SHA256")
					.option("kafka.sasl.jaas.config",
							jaasCfg)
					.save();
			 */

			// Producer
			/*
			dataset.selectExpr("CAST(\"test key\" AS STRING) as key", "CAST(Name AS STRING) as value")
					.write()
					.format("kafka")
					.option("kafka.bootstrap.servers", bootstrapServers)
					.option("topic", topics)
					.option("kafka.security.protocol", "SASL_SSL")
					.option("kafka.sasl.mechanism", "PLAIN")
					.option("kafka.sasl.jaas.config",
							jaasCfg)
					.save();
			*/

			// Consumer
			Dataset<Row> lines = spark
					.read()
					.format("kafka")
					.option("kafka.bootstrap.servers", bootstrapServers)
					.option("subscribe", topics)
					.option("kafka.security.protocol", "SASL_SSL")
					.option("kafka.sasl.mechanism", "PLAIN")
					.option("startingOffsets", "earliest")
					.option("kafka.sasl.jaas.config",
							jaasCfg)
					.load()
					.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)");
			lines.show();
			System.out.println("Kafka Reads:");
			System.out.println(lines.count());

			jsc.stop();
		}

	}
